﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceShooter
{
    //Menu, används för att skapa en meny, lägga till nemyval i menyn samt att ta emot tangenttryckningar för olika menval och att rita ut menyn.
    class Menu
    {
        List<MenuItem> menu; //Lista på menuItems
        int selected = 0; //första valet i listan är valt

        //currentheight används för att rita ut menyItems på olika höjd

        float currentHeight = 0;
        //lastChange används för att pause  tengenttryckingar så att det inte ska gå för fort att bläddra bland menyvalen

        double lastChange = 0;

        //det state som representerar själva menyn

        int defaultMenuState;

        //Menu(), konstruktor som skapar listan med menuItem

        public Menu(int defaultMenuSate)
        {
            menu = new List<MenuItem>();
            this.defaultMenuState = defaultMenuSate;
        }

        //AddItem(), lägger till ett menyval i listan

        public void AddItem (Texture2D itemTexture, int state)
        {
            //sätt höjd på item
            
            float X = 0;
            float Y = 0+currentHeight;


            //ändra currenthieght efter detta item höjd +20 pixlar för lite extra mellanrum
            currentHeight += itemTexture.Height + 20;

            //skaåa ett temporärt objekt och lägg den i listan
            MenuItem temp = new MenuItem(itemTexture, new Vector2(X, Y), state);
            menu.Add(temp);

        }


        //Update(), kollar om användaren tryckt någon tangeent. antigen kan piltangerna användas för att välja en viss menuitem eller så kan enter användas för att gå in i den vlakda menuitem

        public int Update(GameTime gameTime)
        {
            //läs in tangenttryckningar 
            KeyboardState keyboardState = Keyboard.GetState();

            //byte mellan olika menyval.först måste vi dock kontrollera så att användaren inte precis nyligen bytte menyval.

            if(lastChange +130 < gameTime.TotalGameTime.TotalMilliseconds)
            {
                if (keyboardState.IsKeyDown(Keys.Down))
                {
                    selected++;
                    //om vi har gått utanför de möjliga valen, så vill vi att det första mentvalet ska väljas

                    if(selected> menu.Count - 1)
                    {
                        selected = 0; //första menyvalet
                    }
                }
                if (keyboardState.IsKeyDown(Keys.Up))
                {
                    selected--;

                    //om vi har gårr utanför de möjliga valen så vill vi att det sista menyvalet ska väljas

                    if (selected < 0)
                    {
                        selected = menu.Count - 1;
                    }
                }
                //ställ lastchange till exakt detta ögonblick
                lastChange = gameTime.TotalGameTime.TotalMilliseconds;

            }
            //välj ett menyval med enter
            if (keyboardState.IsKeyDown(Keys.Enter))
            {
                return menu[selected].State;//return menyvalet state
            }
            return defaultMenuState;
        }

        //draw() ritar ut menyn
        public void Draw (SpriteBatch spriteBatch)
        {
            for (int i =0; i < menu.Count; i++)
            {
                //om vu har ett aktivt menyval ritat vi ut det med e specielll färgtoning:
                if(i == selected)
                {
                    spriteBatch.Draw(menu[i].Sprite, menu[i].Position, Color.RosyBrown);
                }
                else
                {
                    spriteBatch.Draw(menu[i].Sprite, menu[i].Position, Color.White);

                }
            }
        }

    }
}
