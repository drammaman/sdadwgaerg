﻿
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceShooter
{
    //background, klass för att rita ut en 2d vektor med bakgrundsbilder
    class Background
    {
        BackgroundSprite[,] background;
        int nrBackgroundsX, nrBackgroundsY;

        //BACKGROUND(), KONTRUKTOR som skapar alla backgroundssprite objekt i en tvådimensionell vektor
        public Background(Texture2D sprite, GameWindow window)
        {
            //hur många bilder ska vi ha på breden?
            double tmpX = (double)window.ClientBounds.Width / sprite.Width;

            //avrunda uppåt med math.ceiling()
            nrBackgroundsX = (int)Math.Ceiling(tmpX);

            //hur många bilder ska vu ha på höjden
           double tmpY = (double)window.ClientBounds.Height / sprite.Height;

            nrBackgroundsY = (int)Math.Ceiling(tmpY) + 1;

            //sätt storlek på bektorn
            background = new BackgroundSprite[nrBackgroundsX, nrBackgroundsY];

            //fyll på vektorn med backgroundsspriteobjekt
            for(int i=0; i < nrBackgroundsX; i++)
            {
                for(int j=0; j < nrBackgroundsY; j++)
                {
                    int posX = i * sprite.Width;
                    //gör att deb första hamnar ovanför
                    int posY = j * sprite.Height - sprite.Height;
                    background[i, j] = new BackgroundSprite(sprite, posX, posY);
                }
            }

        }

        //update(), uppdaterar positionen för samtliga backgrooundsprite objekt

        public void Update(GameWindow window)
        {
            for (int i = 0; i < nrBackgroundsX; i++)
                for (int j = 0; j < nrBackgroundsY; j++)
                    background[i, j].Update(window, nrBackgroundsY);
        }
        //draw ritar ut samtliga backgroundssprite objekt
        public void Draw(SpriteBatch spriteBatch)
        {
            for (int i = 0; i < nrBackgroundsX; i++)
                for (int j = 0; j < nrBackgroundsY; j++)
                    background[i, j].Draw(spriteBatch);
        }


    }
}
