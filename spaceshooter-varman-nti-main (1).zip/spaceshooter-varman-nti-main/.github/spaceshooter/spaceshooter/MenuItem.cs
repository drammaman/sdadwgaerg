﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceShooter
{
    //MenuItem, Container klass för ett menyval
    class MenuItem
    {
        Texture2D sprite; // bilden för menyvalet
        Vector2 position; // positionen för mentvalet
        int currentState; //menyvalaets state

        //MenyItem() konstruktor som sätter värden för de olika menyvalen menyvalen

        public MenuItem(Texture2D sprite, Vector2 position, int currentState)
        {
            this.sprite = sprite;
            this.position = position;
            this.currentState = currentState;
        }

        //get- egenskaper för MenyItem
        public Texture2D Sprite { get { return sprite; } } 
        public Vector2 Position { get { return position; } } 
        public int State { get { return currentState; } }


    }
}
