﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceShooter
{
    //BACKGROUNDSSPRITE BEHÅLLAREKLASS FÖR EN BAKGRIDSBILD. DENNA TYP AV BAKGRUNDSBILD ÄR EN DEL AV EN 2DVEKTOR MED FLERA BACKGROUNDSSORITE OBKECT
    class BackgroundSprite : GameObject
    {
        //backgroundsprite(), kontruktor för att skapa backgroundsprite objekt
        public BackgroundSprite(Texture2D sprite, float X, float Y) : base(sprite, X, Y)
        {

        }
        //update (), ändrar positionen för ett backgroundsprite objekt. flyttar det längst upp ifall det har gåt ut i nedkant av skärmen

        public void Update(GameWindow window, int nrBackgrounsY)
        {
            position.Y += 2f; //flytta bakgrunden
            //kontrollera om bakgrunden har åkt ut
            if (position.Y > window.ClientBounds.Height)
            {
                //flytta bilden så att den hamnar ovanför alla andra bakgrundsbilder
                position.Y = position.Y - nrBackgrounsY * sprite.Height;
            }
        }
    }
}
